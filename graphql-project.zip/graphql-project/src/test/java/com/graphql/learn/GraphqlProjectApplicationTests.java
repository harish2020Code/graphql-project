package com.graphql.learn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraphqlProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
